import java.util.regex.Pattern;

public class handler {
    private String firstName,lastName,birthday,course,email;

    public Boolean setFirstName(String firstName) {
        String pattern = "^[a-zA-Z]{1,50}+$";
        boolean checker = Pattern.matches(pattern, firstName);

            if(checker){
                this.firstName = firstName;
                return true;
            }
            else {
                return false;

            }

    }

    public String getFirstName() {

        return firstName;
    }

    public Boolean setLastName(String lastName){

        String pattern = "^[a-zA-Z]{1,50}+$";
        boolean checker = Pattern.matches(pattern, lastName);

        if(checker){
            this.lastName = lastName;
            return true;
        }
        else {
            return false;

        }
    }

    public String getLastName(){

        return lastName;
    }

    public Boolean setBirthday(String birthday) {
        String pattern = "\\d{4}/\\d{2}/\\d{2}";
        boolean regexChecker = Pattern.matches(pattern, birthday);



        if (!regexChecker){
            return false;
        }
        String[] parts = birthday.split("/");

        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int day = Integer.parseInt(parts[2]);
        if (year < (java.time.LocalDate.now().getYear() - 30) || year > (java.time.LocalDate.now().getYear() - 16)){
            return false;
        }
        if (month < 1 || month > 12){
            return false;
        }
        if (day < 1 || day > 31){
            return false;
        }
        if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31){
            return false;

        }

        this.birthday = birthday;
        return true;
    }

    public String getBirthday() {
        return birthday;
    }

    public Boolean setCourse(String course){
        String pattern = "^[a-zA-Z]{1,50}+$";
        boolean checker = Pattern.matches(pattern, course);

        if(checker){
            this.course = course;
            return true;
        }
        else {
            return false;

        }

    }

    public String getCourse(){
        return course;

    }

    public Boolean setEmail(String email){
        String pattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        boolean checker = Pattern.matches(pattern, email);

        if(checker){
            this.email = email;
            return true;
        }
        else {
            return false;

        }

    }


    public String getEmail() {
        return email;
    }


}
