import java.util.Scanner;
import java.time.Year;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        handler handler = new handler();
        Scanner input = new Scanner(System.in);
        boolean checker = false;
        do {

            System.out.println("Enter First Name: ");

            if (handler.setFirstName(input.nextLine())){
                checker = true;
                System.out.println("correct firstname input");
            }
            else{
                checker = false;
                System.out.println("must contain Letters only/Must not exceed to 50 characters");
            }
        }while (!checker);

        do{
            System.out.println("Enter Last Name: ");

            if (handler.setLastName(input.nextLine())){
                checker = true;
                System.out.println("Correct last name input");
            }
            else {
                checker = false;
                System.out.println("must contain Letters only/Must not exceed to 50 characters");

            }
        }while (!checker);

        do {
            System.out.println("Enter your birthday: [YYYY/MM/DD]");

            if (handler.setBirthday(input.nextLine())){
                checker = true;
                System.out.println("Correct birthday input");

            }
            else {
                checker = false;
                System.out.println("Invalid input.");
            }

        }while(!checker);

        do {
            System.out.println("Enter your Course: ");

            if (handler.setCourse(input.nextLine())){
                checker = true;
                System.out.println("Correct course input");
            }
            else {
                checker = false;
                System.out.println("must contain Letters only/Must not exceed to 50 characters");
            }
        }while (!checker);

        do {
            System.out.println("Enter your Email address: ");

            if (handler.setEmail(input.nextLine())){
                checker = true;
                System.out.println("correct email address");
            }
            else {
                checker = false;
                System.out.println("must follow the correct email format.");
            }
        }while (!checker);

        System.out.println("STUDENT INFORMATION");
        System.out.println("");

        System.out.println("First Name: " +handler.getFirstName());
        System.out.println("Last Name: " +handler.getLastName());
        System.out.println("Date of birth: " +handler.getBirthday());
        System.out.println("Course: " +handler.getCourse());
        System.out.println("Email address: " +handler.getEmail());

        String birth = handler.getBirthday();

        int yearNow = LocalDate.now().getYear();

        String[] parts = birth.split("/");

        String birthday = parts[2];

        String number = "01";

        char FirstLetter = handler.getLastName().charAt(0);
        System.out.println("Student Number: ");
        System.out.println(yearNow+ "-" +birthday+number+ "-" +FirstLetter);




    }


}